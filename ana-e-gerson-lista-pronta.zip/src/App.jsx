import React, { useEffect, useMemo, useState } from 'react'

const COUPLE_NAME = "Ana e Gerson";
const WEDDING_DATE = "13/12/2025";
const WHATSAPP_NUMBER = "5519987709406";

const PALETTE = {
  bambu: "#A7C957",
  preto: "#0b0b0b",
  inox: "#B0B7BC",
  branco: "#ffffff",
};

const ITEMS = [
  "Kit Assadeira Antiaderente","Jogo de Panela","Liquidificador","Potes Herméticos","Jogo de Talheres Inox",
  "Kit Utensílios de Cozinha","Jogo de Jantar","Jogo de Xícara","Kit Frigideira Antiaderente","Panela de Arroz Elétrica",
  "Panela de Pressão Elétrica","Chaleira Elétrica","Jogo de Facas de Corte","Jogo de Travessas","Air Fryer",
  "Batedeira Planetária","Espremedor Elétrico","Processador de Alimentos","Sanduicheira","Aparelho de Fondue",
  "Torradeira","Mixer 3 em 1 com Copo Medidor","Cafeteira Elétrica Programável","Kit Panelas de Cerâmica","Jogo de Frigideiras Premium",
  "Aparelho de Jantar de Porcelana Completo","Forno Elétrico de Bancada","Cooktop Portátil por Indução","Panela Wok Antiaderente",
  "Fritadeira sem Óleo Dupla","Grill Elétrico com Controle de Temperatura","Panela Elétrica Multifuncional","Purificador de Água Elétrico",
  "Jogo de Potes Herméticos de Vidro","Jogo de Panelas Tramontina Inox","Máquina de Pão","Jogo de Sobremesa com Taças","Jogo de Copos de Cristal",
  "Jogo de Taças para Vinho","Kit Churrasco com Estojo","Kit Facas para Churrasco Tramontina","Tábua de Frios com Alça","Jogo Americano de Mesa de Luxo",
  "Conjunto de Bowls de Porcelana","Kit Petisqueira com Divisórias","Jogo de Taças para Champanhe","Jogo de Pratos Branco Premium","Aparelho de Fondue Elétrico em Inox",
  "Abajur de Mesa Moderno","Luminária de Chão Articulada","Kit de Almofadas Decorativas","Jogo de Cortinas Blackout","Tapete Felpudo Grande para Sala",
  "Kit Quadros Decorativos","Espelho Decorativo de Parede","Relógio de Parede Vintage","Manta de Sofá Tricotada","Puff Baú Estofado",
  "Poltrona Decorativa","Conjunto de Vasos Decorativos","Bandeja Espelhada Decorativa","Quadro Porta-Rolhas ou Tampinhas","Luminária Pendente para Cozinha",
  "Aromatizador de Ambientes + Difusor","Caixa Organizadora de Madeira com Tampa","Fruteira Decorativa de Metal ou Bambu","Porta-Retrato de Casal","Enfeite de Mesa ou Centro de Sala",
  "Espelho com Luz de Moldura","Luminária de Cabeceira Inteligente","Kit Toalhas de Banho Premium","Kit Cama Completo (Lençol + Fronha + Cobre-leito)","Edredom Queen ou King",
  "Cobre-leito Dupla Face","Roupão Casal","Travesseiros Ortopédicos","Jogo de Colcha Bordada","Cobertor de Microfibra Extra Macio",
  "Tapete Antialérgico de Quarto","Organizador de Sapatos Reforçado","Ferro a Vapor Vertical","Aspirador Vertical 2 em 1","Secadora de Roupas Portátil",
  "Varal Retrátil Inox","Desumidificador Pequeno","Umidificador de Ar","Ventilador de Coluna Silencioso","Aquecedor Elétrico Portátil",
  "Purificador de Ar","Conjunto de Taças para Vinho de Cristal","Balde de Gelo Inox","Kit Bar Completo (Coqueteleira, Dosador, Abridor etc.)","Jogo de Copos para Whisky",
  "Adega Climatizada","Caixa Térmica de Rodinhas","Frigobar Retrô","Jogo de Fondue em Porcelana","Tábua de Corte com Gaveta Inox",
  "Conjunto de Jarras Decoradas","Jogo de Sobremesa de Cristal","Conjunto de Travessas Refratárias Marinex","Conjunto de Xícaras de Porcelana Fina","Kit Bar com Suporte Giratório",
  "Suporte para Vinho de Mesa","Kit Café da Manhã em Bandeja","Kit para Churrasco Elétrico","Mini Geladeira de Bebidas","Mini Adega de Vinhos",
  "Grill Portátil Redondo","Cooktop de Duas Bocas","Caixa de Som Bluetooth","Chromecast ou Fire Stick","Lâmpadas Inteligentes Wi-Fi",
  "Balança Digital Inteligente","Powerbank Personalizado para Casal","Tomadas Inteligentes Wi-Fi","Roteador Wi-Fi de Longo Alcance","Câmera de Segurança Interna",
  "Mini Projetor Portátil","Echo Dot (Alexa)","Relógio Digital de Cabeceira","Carregador Sem Fio Duplo","Aspirador Robô Inteligente"
];

function priceFromName(name){
  let sum = 0;
  for(let i=0;i<name.length;i++) sum += name.charCodeAt(i)*(i+1);
  const base = 120, range = 4800;
  return base + (Math.abs(sum) % range);
}

function formatBRL(n){
  return n.toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
}

export default function App(){
  const [chosen, setChosen] = useState(()=> {
    try{
      const raw = localStorage.getItem('wedding_chosen_v1');
      return raw ? new Set(JSON.parse(raw)) : new Set();
    }catch(e){ return new Set(); }
  });

  useEffect(()=> {
    try{ localStorage.setItem('wedding_chosen_v1', JSON.stringify(Array.from(chosen))); }catch(e){}
  },[chosen]);

  const giftObjects = useMemo(()=> ITEMS.map(name=>{
    const price = priceFromName(name);
    const img = `https://source.unsplash.com/400x300/?${encodeURIComponent(name.split(' ')[0])}&sig=${encodeURIComponent(name)}`;
    return { id:name, name, price, img };
  }),[]);

  function toggleChoose(id){
    setChosen(prev => {
      const next = new Set(prev);
      if(next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-12 bg-white">
      <div className="max-w-5xl mx-auto">
        <header className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-3xl sm:text-4xl font-extrabold" style={{color:PALETTE.preto}}>{COUPLE_NAME}</h1>
            <p className="mt-1 text-sm sm:text-base text-gray-600">{WEDDING_DATE}</p>
          </div>
          <div className="flex items-center gap-3">
            <a href={`https://wa.me/${WHATSAPP_NUMBER}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl border shadow-sm text-sm font-medium" style={{borderColor:PALETTE.inox}}>💬 Contato (WhatsApp)</a>
            <div className="px-3 py-1 rounded-full text-sm font-medium" style={{background:PALETTE.bambu,color:PALETTE.preto}}>Lista Casa & Decoração</div>
          </div>
        </header>

        <section className="mb-6">
          <div className="rounded-2xl p-4 shadow-sm" style={{border:`1px solid ${PALETTE.inox}`}}>
            <p className="text-gray-700">Estamos felizes em compartilhar esse momento com vocês! Veja abaixo nossa lista de presentes 💕</p>
          </div>
        </section>

        <main>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {giftObjects.map(it=>{
              const isChosen = chosen.has(it.id);
              return (
                <article key={it.id} className="relative rounded-2xl overflow-hidden shadow-md border" style={{borderColor:PALETTE.inox}}>
                  <img src={it.img} alt={it.name} className="w-full h-40 object-cover" loading="lazy" />
                  <div className="p-4 bg-white">
                    <h3 className="font-semibold text-sm sm:text-base text-gray-900 mb-1 truncate">{it.name}</h3>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">{formatBRL(it.price)}</span>
                      <div className="text-right text-xs text-gray-500">Aproximado</div>
                    </div>

                    <div className="mt-3 flex gap-2">
                      <button disabled={isChosen} onClick={()=>toggleChoose(it.id)} className="flex-1 px-3 py-2 text-sm rounded-lg font-medium transition-transform transform active:scale-95 focus:outline-none disabled:opacity-60 disabled:cursor-not-allowed" style={{background: isChosen?PALETTE.inox:PALETTE.bambu, color:PALETTE.preto}}>
                        {isChosen? 'Já escolhido' : 'Escolher presente'}
                      </button>
                      <button onClick={()=>window.open(`https://www.google.com/search?q=${encodeURIComponent(it.name)}`,'_blank')} className="px-3 py-2 border rounded-lg text-sm" style={{borderColor:PALETTE.inox}}>Ver</button>
                    </div>
                  </div>

                  {isChosen && <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center"><div className="bg-white/90 px-3 py-1 rounded-xl text-sm font-semibold">Escolhido ✅</div></div>}
                </article>
              )
            })}
          </div>
        </main>

        <footer className="mt-8 rounded-2xl p-4" style={{border:`1px solid ${PALETTE.inox}`}}>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h4 className="font-semibold">Mensagem de agradecimento</h4>
              <p className="text-sm text-gray-700">Agradecemos muito por fazer parte do nosso dia. Cada gesto significa muito para nós!</p>
            </div>

            <div className="flex items-center gap-3">
              <a href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent('Olá! Vi a lista de casamento e queria falar sobre um presente.')}`} target="_blank" rel="noreferrer" className="px-4 py-2 rounded-2xl border shadow-sm text-sm font-medium" style={{borderColor:PALETTE.inox}}>Enviar mensagem</a>
              <button onClick={()=>{ if(window.confirm('Limpar todas as escolhas locais? (apenas no seu navegador)')){ localStorage.removeItem('wedding_chosen_v1'); location.reload(); } }} className="px-3 py-2 rounded-lg text-sm border" style={{borderColor:PALETTE.inox}}>Limpar (local)</button>
            </div>
          </div>

          <div className="mt-4">
            <h5 className="text-sm font-semibold mb-2">Fotos do casal</h5>
            <div className="flex gap-2 overflow-x-auto pb-2">
              <div className="rounded-lg w-40 h-28 bg-gray-100 flex items-center justify-center">Foto</div>
              <div className="rounded-lg w-40 h-28 bg-gray-100 flex items-center justify-center">Foto</div>
              <div className="rounded-lg w-40 h-28 bg-gray-100 flex items-center justify-center">Foto</div>
            </div>
          </div>
        </footer>

        <p className="mt-4 text-xs text-gray-500">Observação: preços são aproximados e gerados automaticamente.</p>
      </div>
    </div>
  )
}
